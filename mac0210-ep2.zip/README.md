======================================================================
MAC0420 - EP2

Arthur Coser Marinho                                     NUSP: 7210629 
Ludmila Ferreira Vicente e Silva                         NUSP: 7557136
======================================================================

Uso:
	octave functions.m
	octave ep2.m <function.dat> <k>

	Onde function.dat contém a malha de pontos e k é a taxa
	de compressão (quantas vez a malha será subdividida, criando
	uma malha mais grossa)

======================================================================

